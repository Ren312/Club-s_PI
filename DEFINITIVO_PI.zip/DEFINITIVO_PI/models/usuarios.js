const mongoose = require('mongoose');

// Esquema para el modelo Usuario
const usuarioSchema = new mongoose.Schema({
  nombre: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  contraseña: { type: String, required: true },
  role: { type: String, enum: ['Estudiante', 'Maestro'], default: 'Estudiante' },
  fecha_creacion: { type: Date, default: Date.now }
});

// Modelo para Usuario
const Usuario = mongoose.model('Usuario', usuarioSchema);

module.exports = Usuario;
