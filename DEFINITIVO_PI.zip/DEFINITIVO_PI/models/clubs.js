const mongoose = require('mongoose');

// Definir el esquema de club
const clubSchema = new mongoose.Schema({
  nombreClub: { type: String, required: true },
  descripcion: { type: String, required: true },
  imagen1: { type: String },
  imagen2: { type: String },
  imagen3: { type: String },
  pagina: { type: String },
  fechaCreacion: { type: Date, default: Date.now }
});

// Crear el modelo basado en el esquema
const Club = mongoose.model('Club', clubSchema);

module.exports = Club;
