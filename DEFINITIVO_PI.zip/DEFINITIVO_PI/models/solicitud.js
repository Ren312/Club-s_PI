const mongoose = require('mongoose');

const solicitudSchema = new mongoose.Schema({
  usuarioId: { type: mongoose.Schema.Types.ObjectId, ref: 'Usuario', required: true },
  clubId: { type: mongoose.Schema.Types.ObjectId, ref: 'Club', required: true },
  carreraId: { type: mongoose.Schema.Types.ObjectId, ref: 'Carrera', required: true },
  matricula: { type: String, required: true },
  horaEstudiantil: { type: String, required: true },
  gradoYGrupo: { type: String, required: true },
  telefono: { type: String, required: true },
  email: { type: String, required: true },
  descripcion: { type: String, required: true },
  fechaSolicitud: { type: Date, default: Date.now },
  estado: { type: String, default: 'Pendiente' },
  nombreClub: { type: String, required: true },
  nombreCarrera: { type: String, required: true }
});

const Solicitud = mongoose.model('Solicitud', solicitudSchema);

module.exports = Solicitud;
