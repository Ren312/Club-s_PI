const mongoose = require('mongoose');

// Definir el esquema de carrera
const carreraSchema = new mongoose.Schema({
  nombreCarrera: { type: String, required: true },
  descripcion: { type: String, required: true },
  fechaCreacion: { type: Date, default: Date.now }
});

// Crear el modelo basado en el esquema
const Carrera = mongoose.model('Carrera', carreraSchema);

module.exports = Carrera;
