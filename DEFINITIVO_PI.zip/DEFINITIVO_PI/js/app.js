const express = require('express');
const mongoose = require('mongoose');
const app = express();

// Middleware para leer cuerpos de solicitudes JSON
app.use(express.json());

// Conexión a MongoDB
mongoose.connect('mongodb://localhost:27017/ClubDB', {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
  .then(() => console.log('Conexión exitosa a MongoDB'))
  .catch(err => console.error('Error de conexión a MongoDB:', err));

// Importar los modelos
const Usuario = require('./models/usuarios');
const Carrera = require('./models/carreras');
const Club = require('./models/clubs');
const Solicitud = require('./models/solicitudes');

// Ruta para obtener todos los usuarios
app.get('/api/usuarios', async (req, res) => {
  try {
    const usuarios = await Usuario.find();
    res.json(usuarios);
  } catch (err) {
    res.status(500).json({ message: 'Error al obtener usuarios', error: err });
  }
});

// Ruta para obtener todas las carreras
app.get('/api/carreras', async (req, res) => {
  try {
    const carreras = await Carrera.find();
    res.json(carreras);
  } catch (err) {
    res.status(500).json({ message: 'Error al obtener carreras', error: err });
  }
});

// Ruta para obtener todos los clubs
app.get('/api/clubs', async (req, res) => {
  try {
    const clubs = await Club.find();
    res.json(clubs);
  } catch (err) {
    res.status(500).json({ message: 'Error al obtener clubs', error: err });
  }
});

// Ruta para obtener todas las solicitudes
app.get('/api/solicitudes', async (req, res) => {
  try {
    const solicitudes = await Solicitud.find()
      .populate('usuarioId', 'nombre email')
      .populate('clubId', 'nombreClub')
      .populate('carreraId', 'nombreCarrera');
    res.json(solicitudes);
  } catch (err) {
    res.status(500).json({ message: 'Error al obtener solicitudes', error: err });
  }
});

// Ruta para crear una nueva solicitud
app.post('/api/solicitudes', async (req, res) => {
  try {
    const { usuarioId, nombreClub, nombreCarrera, matricula, horaEstudiantil, gradoYGrupo, telefono, email, descripcion } = req.body;

    // Buscar el Club y Carrera por nombre
    const club = await Club.findOne({ nombreClub });
    const carrera = await Carrera.findOne({ nombreCarrera });

    if (!club || !carrera) {
      return res.status(400).json({ message: 'Club o Carrera no encontrados' });
    }

    const solicitud = new Solicitud({
      usuarioId,
      clubId: club._id,  // Usamos ObjectId de club
      carreraId: carrera._id,  // Usamos ObjectId de carrera
      matricula,
      horaEstudiantil,
      gradoYGrupo,
      telefono,
      email,
      descripcion,
      nombreClub: club.nombreClub,
      nombreCarrera: carrera.nombreCarrera
    });

    await solicitud.save();
    res.status(201).json(solicitud);
  } catch (err) {
    res.status(500).json({ message: 'Error al crear la solicitud', error: err });
  }
});

// Ruta para actualizar una solicitud
app.put('/api/solicitudes/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { estado } = req.body;

    const solicitud = await Solicitud.findByIdAndUpdate(id, { estado }, { new: true });

    if (!solicitud) {
      return res.status(404).json({ message: 'Solicitud no encontrada' });
    }
    res.json(solicitud);
  } catch (err) {
    res.status(500).json({ message: 'Error al actualizar la solicitud', error: err });
  }
});

// Ruta para eliminar una solicitud
app.delete('/api/solicitudes/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const solicitud = await Solicitud.findByIdAndDelete(id);

    if (!solicitud) {
      return res.status(404).json({ message: 'Solicitud no encontrada' });
    }

    res.json({ message: 'Solicitud eliminada' });
  } catch (err) {
    res.status(500).json({ message: 'Error al eliminar la solicitud', error: err });
  }
});

// Configurar el puerto del servidor
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor corriendo en el puerto ${PORT}`);
});
