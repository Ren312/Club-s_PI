document.addEventListener('DOMContentLoaded', async () => {
  const tabla = document.getElementById('tabla-clubs');

  try {
    const res = await fetch('http://localhost:3000/clubs'); // ajusta la ruta si es diferente
    const clubs = await res.json();

    clubs.forEach(club => {
      const tr = document.createElement('tr');

      tr.innerHTML = `
        <td><input value="${club.nombreClub}" /></td>
        <td><input value="${club.descripcion}" /></td>
        <td>${club.imagen ? `<img src="${club.imagen}" width="60"/>` : '(No disponible)'}</td>
        <td>${club.pagina ? `<a href="${club.pagina}" target="_blank">Ver</a>` : '(No disponible)'}</td>
        <td>
          <button onclick="guardarClub('${club._id}', this)">💾</button>
          <button onclick="eliminarClub('${club._id}', this)">🗑️</button>
        </td>
      `;

      tabla.appendChild(tr);
    });
  } catch (error) {
    console.error('Error cargando clubs:', error);
  }
});

async function guardarClub(id, boton) {
  const fila = boton.closest('tr');
  const nombre = fila.cells[0].querySelector('input').value;
  const descripcion = fila.cells[1].querySelector('input').value;

  try {
    await fetch(`http://localhost:3000/clubs/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nombreClub: nombre, descripcion })
    });
    alert('Club actualizado');
  } catch (error) {
    console.error('Error actualizando:', error);
  }
}

async function eliminarClub(id, boton) {
  if (!confirm('¿Eliminar este club?')) return;

  try {
    await fetch(`http://localhost:3000/clubs/${id}`, { method: 'DELETE' });
    boton.closest('tr').remove();
  } catch (error) {
    console.error('Error eliminando:', error);
  }
}
