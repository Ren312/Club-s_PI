function getCurrentPage() {
  return window.location.pathname.split("/").pop();
}

const currentPage = getCurrentPage();

if ((currentPage === "login.html" || currentPage === "registro.html") &&
    localStorage.getItem("loggedIn") === "true") {
  window.location.href = "./index.html";
}

// ===================
// INDEX.HTML
// ===================
if (currentPage === "index.html" || currentPage === "") {
  const userIcon = document.getElementById("user-icon");
  const profileBox = document.getElementById("user-profile");

  const isLoggedIn = localStorage.getItem("loggedIn") === "true";

  if (userIcon) {
    userIcon.addEventListener("click", (e) => {
      e.preventDefault();
      if (isLoggedIn) {
        profileBox.classList.toggle("hidden");
        fillProfile();
      } else {
        window.location.href = "./login.html";
      }
    });
  }

  document.addEventListener("click", function (e) {
    if (
      profileBox &&
      !profileBox.contains(e.target) &&
      !userIcon.contains(e.target)
    ) {
      profileBox.classList.add("hidden");
    }
  });

  function fillProfile() {
    const nombre = localStorage.getItem("nombre") || "Usuario";
    const club = localStorage.getItem("club");
    const nivel = localStorage.getItem("nivel");
    const carrera = localStorage.getItem("carrera");
    const ingreso = localStorage.getItem("ingreso");

    const textoClub = club && club !== "Sin asignar" ? club : "Esperando unirse a un club";
    const textoNivel = nivel && nivel !== "Pendiente" ? nivel : "Esperando unirse a un club";
    const textoCarrera = carrera && carrera !== "Pendiente" ? carrera : "Esperando unirse a un club";
    const textoIngreso = ingreso && ingreso !== "" && club !== "Sin asignar" ? ingreso : "Pendiente";

    profileBox.innerHTML = `
      <h2>Perfil del Estudiante</h2>
      <p><strong>Nombre:</strong> ${nombre}</p>
      <p><strong>Club:</strong> ${textoClub}</p>
      <p><strong>Nivel / Progreso:</strong> ${textoNivel}</p>
      <p><strong>Carrera:</strong> ${textoCarrera}</p>
      <p><strong>Miembro desde:</strong> ${textoIngreso}</p>
      <button id="logout-btn">Cerrar sesión</button>
    `;

    document.getElementById("logout-btn").addEventListener("click", () => {
      localStorage.clear();
      window.location.href = "./login.html";
    });
  }
}

// ===================
// REGISTRO.HTML
// ===================
if (currentPage === "registro.html") {
  const form = document.getElementById("registro-form");
  const errorMsg = document.getElementById("register-error");

  if (form) {
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      const nombre = document.getElementById("new-username").value.trim();
      const correo = document.getElementById("new-cuenta").value.trim();
      const pass = document.getElementById("new-password").value;
      const confirm = document.getElementById("confirm-password").value;

      if (pass !== confirm) {
        errorMsg.textContent = "Las contraseñas no coinciden.";
        return;
      }

      localStorage.setItem("nombre", nombre);
      localStorage.setItem("correo", correo);
      localStorage.setItem("club", "Sin asignar");
      localStorage.setItem("nivel", "Pendiente");
      localStorage.setItem("carrera", "Pendiente");
      localStorage.setItem("ingreso", new Date().toLocaleDateString());

      window.location.href = "./login.html";
    });
  }
}

// ===================
// LOGIN.HTML
// ===================
if (currentPage === "login.html") {
  const loginForm = document.getElementById("inicio-sesion");
  const error = document.getElementById("register-error");

  if (loginForm) {
    loginForm.addEventListener("submit", function (e) {
      e.preventDefault();
      const user = document.getElementById("username").value.trim();
      const pass = document.getElementById("password").value;

      const isRegistered = localStorage.getItem("nombre") === user;

      if (isRegistered) {
        localStorage.setItem("loggedIn", "true");
        window.location.href = "./solicitud.html";
      } else {
        error.textContent = "Credenciales incorrectas o no registrado.";
      }
    });
  }
}
