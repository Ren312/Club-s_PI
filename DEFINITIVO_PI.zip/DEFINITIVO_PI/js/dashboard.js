    document.getElementById("form-usuario").addEventListener("submit", function (e) {
      e.preventDefault();
      const data = {
        nombre: this.nombre.value,
        email: this.email.value,
        contraseña: this.contraseña.value,
        role: this.rol.value
      };
      const url = this.dataset.editingId ? `http://localhost:3000/users/${this.dataset.editingId}` : "http://localhost:3000/users";
      const method = this.dataset.editingId ? "PUT" : "POST";

      fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
      })
      .then(res => res.json())
      .then(() => {
        alert(this.dataset.editingId ? "Usuario actualizado" : "Usuario agregado");
        this.reset();
        delete this.dataset.editingId;
        this.querySelector("button").textContent = "Agregar Usuario";
        location.reload();
      });
    });

    function editarUsuario(user) {
      const form = document.getElementById("form-usuario");
      form.nombre.value = user.nombre;
      form.email.value = user.email;
      form.rol.value = user.role;
      form.dataset.editingId = user._id;
      form.querySelector("button").textContent = "Actualizar Usuario";
    }

    function eliminarUsuario(id) {
      if (confirm("¿Seguro que deseas eliminar este usuario?")) {
        fetch(`http://localhost:3000/users/${id}`, { method: "DELETE" })
          .then(res => res.json())
          .then(() => {
            alert("Usuario eliminado");
            location.reload();
          });
      }
    }

    fetch("php/get_dashboard_data.php")
      .then(res => res.json())
      .then(data => {
        const resumen = document.getElementById("resumen-clubes");
        data.resumen.forEach(club => {
          const div = document.createElement("div");
          div.className = "card";
          div.innerHTML = `<h3>Club de ${club.nombreClub}</h3><p>${club.inscritos} inscritos</p>`;
          resumen.appendChild(div);
        });

        const progreso = document.getElementById("tabla-progreso");
        data.progreso.forEach(item => {
          progreso.innerHTML += `<tr><td>${item.nombre_estudiante}</td><td>${item.nombre_club}</td><td>${item.porcentaje}</td></tr>`;
        });
      });

    fetch("http://localhost:3000/users")
      .then(res => res.json())
      .then(users => {
        const tabla = document.getElementById("tabla-usuarios");
        users.forEach(user => {
          const fecha = user.fecha_creacion ? new Date(user.fecha_creacion).toLocaleDateString() : "Sin fecha";
          const tr = document.createElement("tr");
          tr.innerHTML = `
            <tr>
  <td>${user.nombre}</td>
  <td>${user.email}</td>
  <td>${user.role}</td>
  <td>${fecha}</td>
  <td>
    <button class="btn-editar" data-id="${user._id}" data-nombre="${user.nombre}" data-email="${user.email}" data-role="${user.role}">✏️</button>
    <button onclick='eliminarUsuario("${user._id}")'>🗑️</button>
  </td>
</tr>

          `;
          tabla.appendChild(tr);
        });
      });

    fetch("http://localhost:3000/carreras")
      .then(res => res.json())
      .then(carreras => {
        const tabla = document.getElementById("tabla-carreras");
        carreras.forEach(c => {
          const fecha = c.fechaCreacion ? new Date(c.fechaCreacion).toLocaleDateString() : "Sin fecha";
          tabla.innerHTML += `<tr><td>${c.nombreCarrera}</td><td>${c.descripcion}</td><td>${fecha}</td></tr>`;
        });
      });

    fetch("http://localhost:3000/solicitudes")
      .then(res => res.json())
      .then(solicitudes => {
        const tabla = document.getElementById("tabla-solicitudes");
        solicitudes.forEach(s => {
          const fecha = s.fechaSolicitud ? new Date(s.fechaSolicitud).toLocaleDateString() : "Sin fecha";
          tabla.innerHTML += `
            <tr>
              <td>${s.matricula}</td>
              <td>${s.email}</td>
              <td>${s.horaEstudiantil}</td>
              <td>${s.gradoYGrupo}</td>
              <td>${s.telefono}</td>
              <td>${s.descripcion}</td>
              <td>${fecha}</td>
              <td>${s.estado}</td>
            </tr>`;
        });
      });