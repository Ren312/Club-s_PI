// Crear el mapa centrado en la dirección proporcionada
var map = L.map('map').setView([26.0510004, -98.2619988], 17); // Zoom 17 para ver con más detalle

// Cargar tiles desde OpenStreetMap
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap contributors'
}).addTo(map);

// Marcador
var marker = L.marker([26.050809, -98.262676]).addTo(map);
marker.bindPopup("<b>Club de basquetbol").openPopup();

//var marker = L.marker([26.051319, -98.261304]).addTo(map);
//marker.bindPopup("<b>Club de Futbol").openPopup();