let index = 0;
const slides = document.querySelectorAll('.slide');

function mostrarSiguienteSlide() {
  slides[index].classList.remove('activo');
  index = (index + 1) % slides.length;
  slides[index].classList.add('activo');
}

setInterval(mostrarSiguienteSlide, 5000);

function abrirModal() {
  document.getElementById('miModal').style.display = 'block';
}

function cerrarModal() {
  document.getElementById('miModal').style.display = 'none';
}

window.onclick = function(event) {
  const modal = document.getElementById('miModal');
  if (event.target == modal) {
    modal.style.display = "none";
  }
}