// server.js
const express = require('express');
const cors = require('cors');
const { MongoClient, ObjectId } = require('mongodb');
const app = express();

app.use(cors());
app.use(express.json());

const uri = 'mongodb://localhost:27017';
const client = new MongoClient(uri);
const dbName = 'ClubDB';

let db;
client.connect().then(() => {
  db = client.db(dbName);
  console.log("Conectado a MongoDB");
});

// ---- CLUBS ----
app.get('/clubs', async (req, res) => {
  const clubs = await db.collection('Clubs').find().toArray();
  console.log("GET /clubs =>", clubs);
  res.json(clubs);
});

app.post('/clubs', async (req, res) => {
  const nuevoClub = req.body;
  await db.collection('Clubs').insertOne(nuevoClub);
  res.json({ mensaje: 'Club agregado con éxito' });
});

app.put('/clubs/:id', async (req, res) => {
  const { id } = req.params;
  const actualizacion = req.body;
  await db.collection('Clubs').updateOne({ _id: new ObjectId(id) }, { $set: actualizacion });
  res.json({ mensaje: 'Club actualizado con éxito' });
});

app.delete('/clubs/:id', async (req, res) => {
  const { id } = req.params;
  await db.collection('Clubs').deleteOne({ _id: new ObjectId(id) });
  res.json({ mensaje: 'Club eliminado con éxito' });
});

// ---- USERS ----
app.get('/users', async (req, res) => {
  const users = await db.collection('Users').find().toArray();
  res.json(users);
});

app.post('/users', async (req, res) => {
  const nuevoUsuario = req.body;
  nuevoUsuario.fecha_creacion = new Date();
  await db.collection('Users').insertOne(nuevoUsuario);
  res.json({ mensaje: 'Usuario agregado con éxito' });
});

app.put('/users/:id', async (req, res) => {
  const { id } = req.params;
  const actualizacion = req.body;
  await db.collection('Users').updateOne({ _id: new ObjectId(id) }, { $set: actualizacion });
  res.json({ mensaje: 'Usuario actualizado con éxito' });
});

app.delete('/users/:id', async (req, res) => {
  const { id } = req.params;
  await db.collection('Users').deleteOne({ _id: new ObjectId(id) });
  res.json({ mensaje: 'Usuario eliminado con éxito' });
});

// ---- CARRERAS ----
app.get('/carreras', async (req, res) => {
  const carreras = await db.collection('Carreras').find().toArray();
  res.json(carreras);
});

app.post('/carreras', async (req, res) => {
  const nuevaCarrera = req.body;
  nuevaCarrera.fechaCreacion = new Date();
  await db.collection('Carreras').insertOne(nuevaCarrera);
  res.json({ mensaje: 'Carrera agregada con éxito' });
});

app.put('/carreras/:id', async (req, res) => {
  const { id } = req.params;
  const actualizacion = req.body;
  await db.collection('Carreras').updateOne({ _id: new ObjectId(id) }, { $set: actualizacion });
  res.json({ mensaje: 'Carrera actualizada con éxito' });
});

app.delete('/carreras/:id', async (req, res) => {
  const { id } = req.params;
  await db.collection('Carreras').deleteOne({ _id: new ObjectId(id) });
  res.json({ mensaje: 'Carrera eliminada con éxito' });
});


// ---- SOLICITUDES ----
app.get('/solicitudes', async (req, res) => {
  const solicitudes = await db.collection('Solicitudes').find().toArray();
  res.json(solicitudes);
});

app.post('/solicitudes', async (req, res) => {
  await db.collection('Solicitudes').insertOne(req.body);
  res.json({ mensaje: 'Solicitud agregada con éxito' });
});

app.put('/solicitudes/:id', async (req, res) => {
  const { id } = req.params;
  await db.collection('Solicitudes').updateOne({ _id: new ObjectId(id) }, { $set: req.body });
  res.json({ mensaje: 'Solicitud actualizada con éxito' });
});

app.delete('/solicitudes/:id', async (req, res) => {
  const { id } = req.params;
  await db.collection('Solicitudes').deleteOne({ _id: new ObjectId(id) });
  res.json({ mensaje: 'Solicitud eliminada con éxito' });
});

// ---- PUERTO ----
app.listen(3000, () => console.log("Servidor en http://localhost:3000"));
