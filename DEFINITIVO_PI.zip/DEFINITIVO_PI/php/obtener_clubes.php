<?php
$conexion = new mysqli("localhost", "root", "", "clubsUTTN");

if ($conexion->connect_error) {
  die("Error de conexión: " . $conexion->connect_error);
}

$resultado = $conexion->query("SELECT * FROM clubes");
$clubs = [];

while ($fila = $resultado->fetch_assoc()) {
  $clubs[] = $fila;
}

header('Content-Type: application/json');
echo json_encode($clubs);

$conexion->close();
?>
