<?php
$conexion = new mysqli("localhost", "root", "", "clubsUTTN");

if ($conexion->connect_error) {
  die("Error de conexión: " . $conexion->connect_error);
}

$nombre = $_POST['nombre'];
$descripcion = $_POST['descripcion'];
$imagen = $_POST['imagen'];
$pagina = $_POST['pagina'];

$sql = "INSERT INTO clubes (nombre, descripcion, imagen, pagina) VALUES (?, ?, ?, ?)";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("ssss", $nombre, $descripcion, $imagen, $pagina);
$stmt->execute();
$stmt->close();

$plantilla = file_get_contents("../plantilla_club.html");
$plantilla = str_replace("[NOMBRE]", $nombre, $plantilla);
$plantilla = str_replace("[DESCRIPCION]", $descripcion, $plantilla);

file_put_contents("../$pagina", $plantilla);

$conexion->close();
header("Location: ../dashboard.html");
exit();
?>
