<?php
$conexion = new mysqli("localhost", "root", "", "clubsuttn");

if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
}

$resultado = $conexion->query("SELECT nombre_club, COUNT(*) AS inscritos FROM progreso GROUP BY nombre_club");

$datos = [];
while ($fila = $resultado->fetch_assoc()) {
    $datos[] = $fila;
}

echo json_encode($datos);
?>
