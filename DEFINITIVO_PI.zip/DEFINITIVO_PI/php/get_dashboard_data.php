<?php
$conexion = new mysqli("localhost", "root", "", "clubsuttn"); // Cambia a tu base real

if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
}

// Resumen General: cuenta cuántos estudiantes hay por club
$resumen = $conexion->query("SELECT nombre_club AS nombre, COUNT(*) AS inscritos FROM progreso GROUP BY nombre_club");

// Progreso Individual: lista detallada
$progreso = $conexion->query("SELECT nombre_estudiante, nombre_club, porcentaje FROM progreso");

$clubs = [];
while ($fila = $resumen->fetch_assoc()) {
    $clubs[] = $fila;
}

$progresos = [];
while ($fila = $progreso->fetch_assoc()) {
    $progresos[] = $fila;
}

echo json_encode([
    "resumen" => $clubs,
    "progreso" => $progresos
]);
?>
